# Ionic + PHP Procedural Students REST API

A small learning/demo REST API for an Ionic Angular standalone app, using PHP and MySQL on XAMPP.

## Requirements
- XAMPP with Apache and MySQL/MariaDB
- PHP 7.4+ (PHP 8.x recommended)
- phpMyAdmin
- Ionic app running in a browser or on a device

## 1. Install the API
1. Extract this ZIP.
2. Copy the `ionic-php-students-api` folder into your XAMPP `htdocs` directory.
   - Windows example: `C:\xampp\htdocs\ionic-php-students-api`
   - macOS XAMPP example: `/Applications/XAMPP/htdocs/ionic-php-students-api`
3. Start **Apache** and **MySQL** in the XAMPP Control Panel/Manager.

## 2. Import the database
1. Open `http://localhost/phpmyadmin`.
2. Select **Import**.
3. Choose `sql/students_api.sql` and click **Import** / **Go**.
4. The SQL creates a database named `ionic_students_api` and a `students` table with a few sample rows.

The default connection settings are in `api/config.php`:
- Host: `localhost`
- Database: `ionic_students_api`
- User: `root`
- Password: empty

These are common XAMPP defaults. Change them if your MySQL setup uses a different account/password.

## 3. Test the API
With Apache and MySQL running, open:

`http://localhost/ionic-php-students-api/api/students.php`

Expected response: JSON containing `success: true` and a `data` array.

### API endpoints
All endpoints use `api/students.php`.

| Method | URL | Purpose |
|---|---|---|
| GET | `/api/students.php` | List all students |
| GET | `/api/students.php?id=1` | Get one student by numeric database ID |
| POST | `/api/students.php` | Create a student |
| PUT | `/api/students.php?id=1` | Update a student |
| DELETE | `/api/students.php?id=1` | Delete a student |

The database `id` is an auto-increment primary key. `student_no` is a unique student identifier.

## 4. Example request bodies

### POST — create a student
Send `Content-Type: application/json`:

```json
{
  "student_no": "2026-0001",
  "full_name": "Juan Dela Cruz",
  "course": "BSIT",
  "year_level": 1
}
```

### PUT — update a student
Send `Content-Type: application/json` to `/api/students.php?id=1`:

```json
{
  "student_no": "2026-0001",
  "full_name": "Juan Dela Cruz",
  "course": "BSIT",
  "year_level": 2
}
```

### DELETE
Send a DELETE request to `/api/students.php?id=1`.

## 5. Connect from Ionic Angular
Use the correct base URL for where the app is running.

- Ionic in the same computer's browser: `http://localhost/ionic-php-students-api/api/students.php`
- Android emulator (Android Studio): commonly `http://10.0.2.2/ionic-php-students-api/api/students.php`
- Physical phone: use your computer's LAN IP, e.g. `http://192.168.1.10/ionic-php-students-api/api/students.php` (phone and computer should be on the same Wi-Fi; allow Apache through your firewall).

`localhost` on a phone refers to the phone itself, not your computer.

### Angular service examples
Assuming your existing `ApiService` has `getData<T>(url: string)`:

```typescript
interface Student {
  id: number;
  student_no: string;
  full_name: string;
  course: string;
  year_level: number;
  created_at: string;
  updated_at: string;
}

// List students
this.api.getData<{success: boolean; data: Student[]}>(API_URL)
  .subscribe(result => console.log(result.data));
```

For POST/PUT/DELETE, add methods to your service using `HttpClient.post`, `put`, and `delete`. Example:

```typescript
createStudent(student: Omit<Student, 'id' | 'created_at' | 'updated_at'>) {
  return this.http.post<{success: boolean; data: Student}>(API_URL, student);
}

updateStudent(id: number, student: Partial<Student>) {
  return this.http.put<{success: boolean; data: Student}>(
    `${API_URL}?id=${id}`, student
  );
}

deleteStudent(id: number) {
  return this.http.delete<{success: boolean; message: string}>(
    `${API_URL}?id=${id}`
  );
}
```

These methods assume `this.http` is available in the service, as in the earlier setup.

## 6. CORS and development notes
- The API allows common localhost development origins and Capacitor's `http://localhost` / `https://localhost` origins.
- For other origins, update `api/students.php`'s CORS allow-list. Do not use wildcard origins with credentials.
- This demo has **no authentication**. Do not expose it publicly or use it for real student records without adding authentication, authorization, HTTPS, validation, and appropriate privacy/security controls.
- If you get a 404, verify the folder is inside `htdocs` and the URL matches the folder name.
- If you get a database connection error, check MySQL is running and the settings in `api/config.php`.
